# Liste des testaments #

* testament 1 (2 images) : 
1914, 2 août. Paris
Testament olographe de Céleste Camille Herpin, mort pour la France à Carency (Pas-de-Calais), le 27 décembre 1914.
Papier timbré, 2 pages, dim. 24,9 x 17,8 cm, encre ; enveloppe, dim. 11,2 x 14,5 cm, encre.
Cote aux Archives nationales :  MC/ET/XXXIII/1848, minute du 29 juillet 1915
[lien vers l'édition sur le site ELEC] (http://elec.enc.sorbonne.fr/testaments-de-poilus/testaments/testament-022.html)
[lien vers la notice relative à C. Herpin] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-testateurs/lettre-H.html#CHerpin)
[lien vers la notice sur Carency] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-lieux-deces/lettre-C.html#pl-027)

* testament 2 (2 images)
1914, 2 août. Paris
Testament olographe d’Émile Simonnet, mort pour la France à Zeitenlik (Grèce), le 30 juin 1916.
Papier à lettre blanc, 2 pages, dim. 17,7 x 10,5 cm, encre.
Cote aux Archives nationales :  MC/ET/LXXXIX/2370, minute du 9 avril 1919 
[lien vers l'édition sur le site ELEC] (http://elec.enc.sorbonne.fr/testaments-de-poilus/testaments/testament-027.html)
[lien vers la notice relative à E. Simonnet] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-testateurs/lettre-S.html#ESimonnet)
[lien vers la notice sur Zeitenlik] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-lieux-deces/lettre-Z.html#pl-101)

* testament 3 (4 images)
1914, 12 août. Nevers (Nièvre)
Testament olographe de Lucien Pierre Armand Debain, mort pour la France à Vitry-le-François (Marne), le 16 novembre 1915.
Papier à lettre blanc, 4 pages, dim. 18 x 14 cm, encre ; enveloppe, dim. 10 x 14,5 cm, encre.
Cote aux Archives nationales :  MC/ET/LXXXIX/2343, minute du 13 janvier 1916 
[lien vers l'édition sur le site ELEC] (http://elec.enc.sorbonne.fr/testaments-de-poilus/testaments/testament-060.html)
[lien vers la notice relative à P. Debain] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-testateurs/lettre-D.html#LDebain)
[lien vers la notice sur Vitry-le-François] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-lieux-deces/lettre-V.html#pl-100)

* testament 4 (4 images)
1915, 25 juin. Chartres (Eure-et-Loir)
Testament olographe de Marcel Étienne, mort pour la France à Dugny (Meuse), le 3 mai 1916.
Papier à lettre quadrillé, 2 pages, dim. 12,3 x 19,4 cm, encre ; enveloppe, dim. 10 x 14,7 cm, encre, 5 cachets.
Cote aux Archives nationales :  MC/ET/XXXIII/1865, minute du 7 novembre 1916 
[lien vers l'édition sur le site ELEC] (http://elec.enc.sorbonne.fr/testaments-de-poilus/testaments/testament-096.html)
[lien vers la notice relative à M. Étienne] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-testateurs/lettre-E.html#MEtienne)
[lien vers la notice sur Dugny] (http://elec.enc.sorbonne.fr/testaments-de-poilus/index-lieux-deces/lettre-D.html#pl-034)
